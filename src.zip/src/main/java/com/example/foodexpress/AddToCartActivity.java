package com.example.foodexpress;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.foodexpress.Database.DatabaseHelper;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AddToCartActivity extends AppCompatActivity {

    Food food;
    SessionManager sessionManager;
    ElegantNumberButton elegantNumberButton;
    TextView textViewFoodPrice, textViewFoodName;
    Button btn_addToCart;
    DatabaseHelper databaseHelper;
    DatabaseReference foods;
    String ttlPrice;
    CartActivity cartActivity;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ArrayList<Order> orderList;
    Order order;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_to_cart);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sessionManager = new SessionManager(getApplicationContext());
        food = new Food();
        order = new Order();
        orderList = new ArrayList<>();
        databaseHelper = new DatabaseHelper(AddToCartActivity.this);

        //initiate views
        btn_addToCart = (Button) findViewById(R.id.btn_addToCart);
        textViewFoodName = (TextView) findViewById(R.id.header_food_name);
        textViewFoodPrice = (TextView) findViewById(R.id.textViewFoodPrice);
        elegantNumberButton = (ElegantNumberButton) findViewById(R.id.btn_number);

        //get data from food activity
        Intent i = getIntent();
        food = (Food) i.getSerializableExtra("food_class");
        final String food_id = food.getFood_id();
        updateTextViewPrice(1);

        textViewFoodPrice.setText("RM " + food.getFood_price());
        textViewFoodName.setText(food.getFood_name());

        //set views
        elegantNumberButton.setOnClickListener(new ElegantNumberButton.OnClickListener() {
            @Override
            public void onClick(View view) {
                String num = elegantNumberButton.getNumber();
            }
        });

        elegantNumberButton.setOnValueChangeListener(new ElegantNumberButton.OnValueChangeListener() {
            @Override
            public void onValueChange(ElegantNumberButton view, int oldValue, int newValue) {
                Log.d(AddToCartActivity.class.getSimpleName(), String.format("oldValue: %d   newValue: %d", oldValue, newValue));
                updateTextViewPrice(Integer.parseInt(elegantNumberButton.getNumber()));
            }
        });

        btn_addToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                orderList.clear();
                orderList.addAll(databaseHelper.getAllOrders());
                if (orderList.isEmpty()){
                    addToCart(food_id);
                }else{
                    boolean isAdded = false;
                    for (int i=0; i<orderList.size(); i++) {
                        order = orderList.get(i);
                        if (food_id.equals(order.getFood_id())) {
                            int qty = Integer.parseInt(order.getFood_qty()) + Integer.parseInt(elegantNumberButton.getNumber());
                            order.setFood_qty(Integer.toString(qty));
                            orderList.set(i, order);
                            databaseHelper.updateCartItem(order);
                            Toast.makeText(AddToCartActivity.this, "Added to Cart!", Toast.LENGTH_SHORT).show();
                            Intent cart = new Intent(AddToCartActivity.this, CartActivity.class);
                            startActivity(cart);
                            isAdded = true;
                            finish();
                        }
                    }
                    if (isAdded == false){
                        final String[] r_id = new String[1];

                        //get the order item in cart
                        order = new Order();
                        orderList.clear();
                        orderList.addAll(databaseHelper.getAllOrders());
                        order = orderList.get(0);

                        //get data from firebase to check
                        firebaseDatabase = FirebaseDatabase.getInstance();
                        databaseReference = firebaseDatabase.getReference("tbl_food");
                        databaseReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for (DataSnapshot ds : snapshot.getChildren()){
                                    if (ds.exists()){
                                        if (order.getFood_id().equals(ds.child("f_id").getValue())) {
                                            r_id[0] = ds.child("r_id").getValue().toString();
                                        }
                                    }
                                }
                                //check if item selected has the same restaurant id with the item in cart
                                if (food.getRestaurant_id().equals(r_id[0])){
                                    addToCart(food_id);
                                }else{
                                    String text = "Unable to add items from other restaurants! ";
                                    Toast.makeText(AddToCartActivity.this, text, Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                System.out.println("The read failed: " + error.getCode());
                            }
                        });
                        finish();
                    }
                }
            }
        });

    }

    private void addToCart(String food_id){
        new DatabaseHelper(getBaseContext()).addToCart(new Order(
                food_id,
                food.getFood_name(),
                elegantNumberButton.getNumber(),
                food.getFood_price(),
                food.getRestaurant_id()
        ));

        Toast.makeText(AddToCartActivity.this, "Added to Cart!", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void updateTextViewPrice(int num) {
        Double netPrice = Double.parseDouble(food.getFood_price());
        netPrice = netPrice * num;
        Double totalPrice = round(netPrice, 2);
        ttlPrice = String.format("%.2f", totalPrice);
        textViewFoodPrice.setText("RM " + ttlPrice);
    }


    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
}