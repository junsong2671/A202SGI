package com.example.foodexpress;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foodexpress.Database.DatabaseHelper;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class OrderHistoryActivity extends AppCompatActivity {

    private AppCompatActivity activity;
    RecyclerView recyclerView;
    ArrayList<History> historyList;
    History history;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    SessionManager sessionManager;
    OrderHistoryAdapter orderHistoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        historyList = new ArrayList<>();
        history = new History();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("tbl_order");
        sessionManager = new SessionManager(getApplicationContext());
        HashMap<String, String> user = sessionManager.getUserDetails();
        final String id = user.get(SessionManager.KEY_ID);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()){
                    if (ds.exists()){
                        if (ds.child("u_id").getValue().equals(id)) {
                            historyList.add(new History(ds.child("h_id").getValue().toString(),
                                    ds.child("u_id").getValue().toString(),
                                    ds.child("r_id").getValue().toString(),
                                    ds.child("h_date").getValue().toString(),
                                    ds.child("h_totalPrice").getValue().toString()));
                        }
                    }
                }
                recyclerView = findViewById(R.id.rvOrderHistory);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(OrderHistoryActivity.this));
                orderHistoryAdapter = new OrderHistoryAdapter(getBaseContext(), historyList);
                recyclerView.setAdapter(orderHistoryAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("The read failed: " + error.getCode());
            }
        });
    }
}