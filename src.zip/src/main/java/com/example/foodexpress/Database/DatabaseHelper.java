package com.example.foodexpress.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import com.example.foodexpress.Order;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "foodExpress.db";
    private static final int DB_VER = 1;
    private static final String TABLE_CART = "OrderDetail";
    private static final String FOOD_ID = "food_id";
    private static final String FOOD_NAME = "food_name";
    private static final String FOOD_QTY = "food_qty";
    private static final String FOOD_PRICE = "food_price";
    private static final String RESTAURANT_ID = "restaurant_id";
    private String CREATE_CART_TABLE = "CREATE TABLE " + TABLE_CART + "("
            + FOOD_ID + " TEXT,"
            + FOOD_NAME + " TEXT,"
            + FOOD_QTY + " TEXT,"
            + FOOD_PRICE + " TEXT,"
            + RESTAURANT_ID + " TEXT" + ")";
    private String DROP_CART_TABLE = "DROP TABLE IF EXISTS " + TABLE_CART;
    Order order;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VER);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_CART_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_CART_TABLE);
        onCreate(db);
    }

    public List<Order> getCart(){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {"food_id", "food_name", "food_qty", "food_price", "restaurant_id"};
        String sqlTable = "OrderDetail";

        qb.setTables(sqlTable);
        Cursor c = qb.query(db, sqlSelect, null,null,null,null,null);

        final List<Order> result = new ArrayList<>();
        if (c.moveToFirst()){
            do {
                result.add(new Order(c.getString(c.getColumnIndex("food_id")),
                        c.getString(c.getColumnIndex("food_name")),
                        c.getString(c.getColumnIndex("food_qty")),
                        c.getString(c.getColumnIndex("food_price")),
                        c.getString(c.getColumnIndex("restaurant_id"))
                    ));

            } while (c.moveToNext());
        }
        return result;
    }

    public void addToCart(Order order){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(FOOD_ID, order.getFood_id());
        values.put(FOOD_NAME, order.getFood_name());
        values.put(FOOD_QTY, order.getFood_qty());
        values.put(FOOD_PRICE, order.getFood_price());
        values.put(RESTAURANT_ID, order.getRestaurant_id());

        //Inserting Row
        db.insert(TABLE_CART, null, values);
        db.close();
    }

    public void updateCartItem(Order order){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(FOOD_ID, order.getFood_id());
        values.put(FOOD_NAME, order.getFood_name());
        values.put(FOOD_QTY, order.getFood_qty());
        values.put(FOOD_PRICE, order.getFood_price());
        values.put(RESTAURANT_ID, order.getRestaurant_id());

        //Updating Row
        db.update(TABLE_CART, values, FOOD_ID + " = ?", new String[]{String.valueOf(order.getFood_id())});
        db.close();
    }

    public void emptyCart(){
        SQLiteDatabase db = getWritableDatabase();
        String query = String.format("DELETE FROM OrderDetail");
        db.execSQL(query);
    }


    public void deleteOrder(Order order) {
        try{
            SQLiteDatabase db = this.getWritableDatabase();
            // delete category record
            db.delete(TABLE_CART, FOOD_ID + " = ?", new String[]{String.valueOf(order.getFood_id())});
            db.close();
        }catch(SQLException e){

        }
    }

    public ArrayList<Order> getAllOrders() {
        // array of columns to fetch
        String[] columns = {
                FOOD_ID,
                FOOD_NAME,
                FOOD_QTY,
                FOOD_PRICE,
                RESTAURANT_ID,
        };

        ArrayList<Order> orderList = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        // query the category table
        Cursor cursor = db.query(TABLE_CART, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                order = new Order();
                order.setFood_id(cursor.getString(cursor.getColumnIndex(FOOD_ID)));
                order.setFood_name(cursor.getString(cursor.getColumnIndex(FOOD_NAME)));
                order.setFood_qty(cursor.getString(cursor.getColumnIndex(FOOD_QTY)));
                order.setFood_price(cursor.getString(cursor.getColumnIndex(FOOD_PRICE)));
                order.setRestaurant_id(cursor.getString(cursor.getColumnIndex(RESTAURANT_ID)));
                orderList.add(new Order(order.getFood_id(), order.getFood_name(), order.getFood_qty(), order.getFood_price(), order.getRestaurant_id()));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return orderList;
    }
}
