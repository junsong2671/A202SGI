package com.example.foodexpress;

class User {
    public String user_id;
    public String user_email;
    public String user_name;
    public String user_type;
    public String user_phone;

    public User(){
        this.user_id = "";
        this.user_name = "";
        this.user_email = "";
        this.user_phone = "";
        this.user_type = "";
    }

    public User(String user_id, String user_email, String user_name, String user_phone, String user_type){
        this.user_id = user_id;
        this.user_name = user_name;
        this.user_phone = user_phone;
        this.user_email = user_email;
        this.user_type = user_type;
    }

    public String getUser_id(){
        return user_id;
    }

    public String getUser_email(){
        return user_email;
    }

    public String getUser_name(){
        return user_name;
    }

    public String getUser_phone(){
        return user_phone;
    }

    public String getUser_type(){
        return user_type;
    }
}
