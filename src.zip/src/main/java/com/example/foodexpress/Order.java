package com.example.foodexpress;

public class Order {
    public String food_id;
    public String food_name;
    public String food_qty;
    public String food_price;
    public String restaurant_id;

    public Order(){
        food_id = "";
        food_name = "";
        food_qty = "";
        food_price = "";
        restaurant_id = "";
    }

    public Order(String food_id, String food_name, String food_qty, String food_price, String restaurant_id) {
        this.food_id = food_id;
        this.food_name = food_name;
        this.food_qty = food_qty;
        this.food_price = food_price;
        this.restaurant_id = restaurant_id;
    }

    public String getFood_name() {
        return food_name;
    }

    public void setFood_name(String food_name) {
        this.food_name = food_name;
    }

    public String getFood_id() {
        return food_id;
    }

    public void setFood_id(String food_id) {
        this.food_id = food_id;
    }

    public String getFood_qty() {
        return food_qty;
    }

    public void setFood_qty(String food_qty) {
        this.food_qty = food_qty;
    }

    public String getFood_price() {
        return food_price;
    }

    public void setFood_price(String food_price) {
        this.food_price = food_price;
    }

    public String getRestaurant_id() {
        return restaurant_id;
    }

    public void setRestaurant_id(String restaurant_id) {
        this.restaurant_id = restaurant_id;
    }
}
