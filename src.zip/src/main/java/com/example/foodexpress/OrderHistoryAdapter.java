package com.example.foodexpress;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class OrderHistoryAdapter extends RecyclerView.Adapter<OrderHistoryAdapter.ViewHolder> {

    private ArrayList<History> historyList;
    private Context context;

    public OrderHistoryAdapter(Context context, ArrayList<History> historyList) {
        this.context = context;
        this.historyList = historyList;
    }

    @Override
    public OrderHistoryAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_cart_item, parent, false);

        // inflating recycler item view
        return new OrderHistoryAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(OrderHistoryAdapter.ViewHolder holder, int position) {

        final History currentHistory = historyList.get(position);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        holder.bindTo(currentHistory);
    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView textViewOrderHistoryId;
        public TextView textViewDateOrderPlaced;
        public TextView textViewTotalPrice;


        public ViewHolder(View view) {
            super(view);
            textViewOrderHistoryId = (TextView) view.findViewById(R.id.textViewName);
            textViewDateOrderPlaced = (TextView) view.findViewById(R.id.textViewCartQty);
            textViewTotalPrice = (TextView) view.findViewById(R.id.textViewCartPrice);
        }

        public void bindTo(History currentHistory){
            //Populate the text views with data
            textViewOrderHistoryId.setText(currentHistory.getH_id());
            textViewDateOrderPlaced.setText(currentHistory.getH_date());
            textViewTotalPrice.setText("RM " + currentHistory.getH_totalPrice());
        }
    }
}
