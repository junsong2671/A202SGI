package com.example.foodexpress;

import java.io.Serializable;

class Food implements Serializable {
    public String food_id;
    public String food_name;
    public String food_price;
    public String restaurant_id;

    public Food() {
        food_id = "";
        food_name = "";
        food_price = "";
        restaurant_id = "";
    }

    public Food(String food_id, String food_name, String food_price, String restaurant_id){
        this.food_id = food_id;
        this.food_name = food_name;
        this.food_price = food_price;
        this.restaurant_id = restaurant_id;
    }

    public void setFood_id(String food_id){
        this.food_id = food_id;
    }

    public String getFood_id() {
        return food_id;
    }

    public void setFood_name(String food_name) {
        this.food_name = food_name;
    }

    public String getFood_name() {
        return food_name;
    }

    public void setFood_price(String food_price) {
        this.food_price = food_price;
    }

    public String getFood_price() {
        return food_price;
    }

    public void setRestaurant_id(String restaurant_id) {
        this.restaurant_id = restaurant_id;
    }

    public String getRestaurant_id() {
        return restaurant_id;
    }
}
