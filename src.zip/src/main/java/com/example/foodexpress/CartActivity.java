package com.example.foodexpress;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foodexpress.Database.DatabaseHelper;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;

public class CartActivity extends AppCompatActivity {

    AppCompatActivity activity;
    RecyclerView recyclerView;
    CartAdapter cartAdapter;
    Order order;
    TextView textViewSubtotalPrice, textViewDeliveryFeePrice, textViewTotalPrice;
    Button btn_checkout, btn_emptyCart;
    ArrayList<Order> orderList;
    ArrayList<History> historyList;
    DatabaseHelper databaseHelper;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    SessionManager sessionManager;
    History history;
    int history_id;
    public static final String DATE_FORMAT_8 = "yyyy-MM-dd HH:mm:ss";
    SimpleDateFormat dateFormat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_baseline_close_24);

        //initiate views
        btn_checkout = (Button) findViewById(R.id.btn_checkout);
        btn_emptyCart = (Button) findViewById(R.id.btn_emptyCart);
        textViewSubtotalPrice = (TextView) findViewById(R.id.textViewSubtotalPrice);
        textViewDeliveryFeePrice = (TextView) findViewById(R.id.textViewDeliveryFeePrice);
        textViewTotalPrice = (TextView) findViewById(R.id.textViewTotalPrice);

        sessionManager = new SessionManager(getApplicationContext());
        databaseHelper = new DatabaseHelper(CartActivity.this);
        history = new History();
        orderList = new ArrayList<>();
        historyList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.rvCart);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(CartActivity.this));
        cartAdapter = new CartAdapter(getBaseContext(), orderList);
        recyclerView.setAdapter(cartAdapter);
        historyList = getDataFromFirebase();
        getDataFromSQLite();
        enableSwipeToDeleteAndUndo();
        updateOrderDetails();

        btn_emptyCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseHelper.emptyCart();
                cartAdapter.notifyDataSetChanged();
                Toast.makeText(CartActivity.this, "Cart is Emptied !", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        btn_checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //retrieve user id from session variables
                HashMap<String, String> user = sessionManager.getUserDetails();
                String id = user.get(SessionManager.KEY_ID);
                history_id = historyList.size();
                dateFormat = new SimpleDateFormat(DATE_FORMAT_8);
                history.setH_id("H0000" + (history_id + 1));
                history.setU_id(id);
                history.setR_id(order.getRestaurant_id());
                history.setH_date(getCurrentDate(dateFormat));
                history.setH_totalPrice(String.format(" %.2f", getTotalPrice()));
                databaseReference = firebaseDatabase.getReference("tbl_order");
                databaseReference.child(history.getH_id()).setValue(history);
                databaseHelper.emptyCart();
                finish();
            }
        });
    }

    private ArrayList<History> getDataFromFirebase() {
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("tbl_order");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds: snapshot.getChildren()){
                    if (ds.exists()) {
                        historyList.add(new History(ds.child("h_id").getValue().toString(),
                                ds.child("u_id").getValue().toString(),
                                ds.child("r_id").getValue().toString(),
                                ds.child("h_date").getValue().toString(),
                                ds.child("h_totalPrice").getValue().toString()));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("The read failed: " + error.getCode());
            }
        });
        return historyList;
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish(); // close this activity as oppose to navigating up
        return false;
    }

    private void enableSwipeToDeleteAndUndo() {
        SwipeToDeleteCallback swipeToDeleteCallback = new SwipeToDeleteCallback(this) {
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                final int position = viewHolder.getAdapterPosition();
                final Order order = getData().get(position);

                removeItem(position, order);
                updateOrderDetails();
                Toast.makeText(CartActivity.this, "Item is removed from the cart!", Toast.LENGTH_SHORT).show();
            }

            private void removeItem(int position, Order order) {
                orderList.remove(position);
                cartAdapter.notifyItemRemoved(position);
                databaseHelper.deleteOrder(order);
                orderList.clear();
                orderList.addAll(databaseHelper.getAllOrders());
                if (orderList.size()<1){
                    finish();
                }
            }

            public ArrayList<Order> getData() {
                return orderList;
            }
        };

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeToDeleteCallback);
        itemTouchhelper.attachToRecyclerView(recyclerView);
    }

    private void updateOrderDetails() {
        Double subtotal = 0.0;
        Double deliveryFee = 4.99;
        Double total = 0.0;
        order = new Order();
        orderList.clear();
        orderList.addAll(databaseHelper.getAllOrders());
        for (int i=0; i<orderList.size(); i++){
            order = orderList.get(i);
            subtotal = subtotal + (Double.parseDouble(order.food_price) * Double.parseDouble(order.getFood_qty()));
        }

        total = subtotal + deliveryFee;

        textViewSubtotalPrice.setText(String.format("RM %.2f", subtotal));
        textViewDeliveryFeePrice.setText(String.format("RM %.2f", deliveryFee));
        textViewTotalPrice.setText(String.format("RM %.2f", total));
    }

    private Double getTotalPrice(){
        Double subtotal = 0.0;
        Double deliveryFee = 4.99;
        Double total = 0.0;
        order = new Order();
        orderList.clear();
        orderList.addAll(databaseHelper.getAllOrders());
        for (int i=0; i<orderList.size(); i++){
            order = orderList.get(i);
            subtotal = subtotal + (Double.parseDouble(order.food_price) * Double.parseDouble(order.getFood_qty()));
        }

        total = subtotal + deliveryFee;
        return total;
    }

    public static String getCurrentDate(SimpleDateFormat dateFormat) {
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date today = Calendar.getInstance().getTime();
        return dateFormat.format(today);
    }

    private void getDataFromSQLite() {
        orderList.clear();
        orderList.addAll(databaseHelper.getAllOrders());
        if (orderList.size() < 1) {
            Toast.makeText(this, "Cart is Empty! ", Toast.LENGTH_SHORT).show();
            finish();
        }
        cartAdapter.notifyDataSetChanged();
    }
}