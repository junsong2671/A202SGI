package com.example.foodexpress;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class RestaurantAdapter extends RecyclerView.Adapter<RestaurantAdapter.ViewHolder> {

    private ArrayList<Restaurant> restaurantList;
    private Context mContext;

    public RestaurantAdapter(Context context, ArrayList<Restaurant> restaurantList){
        this.restaurantList = restaurantList;
        this.mContext = context;
    }

    @Override
    public RestaurantAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false);

        // inflating recycler item view
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RestaurantAdapter.ViewHolder holder, int position) {

        //Get current category
        final Restaurant currentRestaurant = restaurantList.get(position);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(mContext, FoodActivity.class);
                i.putExtra("restaurant_class", currentRestaurant);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(i);
            }
        });

        //Populate the text views with data
        holder.bindTo(currentRestaurant);
    }

    @Override
    public int getItemCount() {
        Log.v(RestaurantAdapter.class.getSimpleName(),"Total items showing: "+ restaurantList.size());
        return restaurantList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView textViewName;
        public TextView textViewType;
        public ImageView mImageView;

        public ViewHolder(View view) {
            super(view);
            textViewName = (TextView) view.findViewById(R.id.textViewName);
            textViewType = (TextView) view.findViewById(R.id.textViewType);
            mImageView = (ImageView) view.findViewById(R.id.iv_restaurant);
        }

        public void bindTo(Restaurant currentRestaurant) {
            //Populate the text views with data
            textViewName.setText(currentRestaurant.getRestaurantName());
            textViewType.setText(currentRestaurant.getRestaurantType());
            //Glide.with(mContext).load(currentCat.getImageResource()).into(mImageView);
        }
    }
}
