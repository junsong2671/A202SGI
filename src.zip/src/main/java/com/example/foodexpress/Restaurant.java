package com.example.foodexpress;

import java.io.Serializable;

public class Restaurant implements Serializable {
    public String restaurantId;
    public String restaurantName;
    public String restaurantType;


    public Restaurant(){
        this.restaurantId = "";
        this.restaurantName = "";
        this.restaurantType = "";
    }
    public Restaurant(String restaurantId, String restaurantName, String restaurantType){
        this.restaurantId = restaurantId;
        this.restaurantName = restaurantName;
        this.restaurantType = restaurantType;
    }

    public String getRestaurantId(){ return restaurantId; }

    public void setRestaurantId(String restaurantId){
        this.restaurantId = restaurantId;
    }

    public String getRestaurantName(){
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName){
        this.restaurantName = restaurantName;
    }

    public String getRestaurantType(){
        return restaurantType;
    }

    public void setRestaurantType(String restaurantType){
        this.restaurantType = restaurantType;
    }
}
