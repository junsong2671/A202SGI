package com.example.foodexpress;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {

    private ArrayList<Order> orderList;
    private Context context;

    public CartAdapter(Context context, ArrayList<Order> orderList) {
        this.context = context;
        this.orderList = orderList;
    }

    @Override
    public CartAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_cart_item, parent, false);

        // inflating recycler item view
        return new CartAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CartAdapter.ViewHolder holder, int position) {

        //Get current order
        final Order currentOrder = orderList.get(position);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        //Populate the text views with data
        holder.bindTo(currentOrder);
    }

    @Override
    public int getItemCount() {
        Log.v(CartAdapter.class.getSimpleName(),"Total items showing: "+ orderList.size());
        return orderList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView textViewName;
        public TextView textViewQty;
        public TextView textViewPrice;

        public ViewHolder(View view) {
            super(view);
            textViewName = (TextView) view.findViewById(R.id.textViewName);
            textViewQty = (TextView) view.findViewById(R.id.textViewCartQty);
            textViewPrice = (TextView) view.findViewById(R.id.textViewCartPrice);
        }

        public void bindTo(Order currentOrder) {
            //Populate the text views with data
            textViewName.setText(currentOrder.getFood_name());
            textViewQty.setText("x " + currentOrder.getFood_qty());
            textViewPrice.setText("RM " + currentOrder.getFood_price());
        }
    }
}
