package com.example.foodexpress;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Adapter;
import android.widget.Toast;

import com.google.firebase.FirebaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class RestaurantActivity extends AppCompatActivity {

    private AppCompatActivity activity = RestaurantActivity.this;
    RecyclerView recyclerView;
    ArrayList<Restaurant> restaurantList;
    RestaurantAdapter restaurantAdapter;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    SessionManager sessionManager;
    Restaurant restaurant;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sessionManager = new SessionManager(getApplicationContext());
        restaurantList = new ArrayList<>();
        restaurant = new Restaurant();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("tbl_restaurant");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()){
                    if (ds.exists()){
                        restaurantList.add(new Restaurant(ds.child("r_id").getValue().toString(),
                                ds.child("r_name").getValue().toString(),
                                ds.child("r_type").getValue().toString()));
                    }
                }
                recyclerView = findViewById(R.id.rvRestaurant);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(RestaurantActivity.this));
                restaurantAdapter = new RestaurantAdapter(getBaseContext(), restaurantList);
                recyclerView.setAdapter(restaurantAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("The read failed: " + error.getCode());
            }
        });
    }
}