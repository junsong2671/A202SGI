package com.example.foodexpress;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.ViewHolder> {

    private ArrayList<Food> foodList;
    private Context mContext;

    public FoodAdapter(Context context, ArrayList<Food> foodList){
        this.foodList = foodList;
        this.mContext = context;
    }

    @Override
    public FoodAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false);

        // inflating recycler item view
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(FoodAdapter.ViewHolder holder, int position) {

        //Get current category
        final Food currentFood = foodList.get(position);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(mContext, AddToCartActivity.class);
                i.putExtra("food_class", currentFood);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(i);
            }
        });

        //Populate the text views with data
        holder.bindTo(currentFood);
    }

    @Override
    public int getItemCount() {
        Log.v(FoodAdapter.class.getSimpleName(),"Total items showing: "+ foodList.size());
        return foodList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView textViewName;
        public TextView textViewType;
        public ImageView mImageView;

        public ViewHolder(View view) {
            super(view);
            textViewName = (TextView) view.findViewById(R.id.textViewName);
            textViewType = (TextView) view.findViewById(R.id.textViewType);
            mImageView = (ImageView) view.findViewById(R.id.iv_restaurant);
        }

        public void bindTo(Food currentFood) {
            //Populate the text views with data
            textViewName.setText(currentFood.getFood_name());
            textViewType.setText(updateTextViewPrice(currentFood.getFood_price()));
            //Glide.with(mContext).load(currentFood.getImageResource()).into(mImageView);
        }
    }
    private String updateTextViewPrice(String price) {
        Double netPrice = Double.parseDouble(price);
        Double totalPrice = round(netPrice, 2);
        String ttlPrice = String.format("RM %.2f", totalPrice);

        return ttlPrice;
    }

    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
}
