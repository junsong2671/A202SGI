package com.example.foodexpress;

public class History {
    public String h_id;
    public String u_id;
    public String r_id;
    public String h_date;
    public String h_totalPrice;

    public History(){
        h_id = "";
        u_id = "";
        r_id = "";
        h_date = "";
        h_totalPrice = "";
    }

    public History(String h_id, String u_id, String r_id, String h_date, String h_totalPrice) {
        this.h_id = h_id;
        this.u_id = u_id;
        this.r_id = r_id;
        this.h_date = h_date;
        this.h_totalPrice = h_totalPrice;
    }

    public String getH_id() {
        return h_id;
    }

    public void setH_id(String h_id) {
        this.h_id = h_id;
    }

    public String getU_id() {
        return u_id;
    }

    public void setU_id(String u_id) {
        this.u_id = u_id;
    }

    public String getR_id() {
        return r_id;
    }

    public void setR_id(String r_id) {
        this.r_id = r_id;
    }

    public String getH_date() {
        return h_date;
    }

    public void setH_date(String h_date) {
        this.h_date = h_date;
    }

    public String getH_totalPrice() {
        return h_totalPrice;
    }

    public void setH_totalPrice(String h_totalPrice) {
        this.h_totalPrice = h_totalPrice;
    }
}
