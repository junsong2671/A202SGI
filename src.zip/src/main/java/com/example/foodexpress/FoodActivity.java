package com.example.foodexpress;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class FoodActivity extends AppCompatActivity {

    private AppCompatActivity activity = FoodActivity.this;
    RecyclerView recyclerView;
    ArrayList<Food> foodList;
    FoodAdapter foodAdapter;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    SessionManager sessionManager;
    Food food;
    Restaurant restaurant;
    TextView textViewName;
    TextView textViewType;
    Button btn_viewCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sessionManager = new SessionManager(getApplicationContext());
        foodList = new ArrayList<>();
        food = new Food();

        //get data from restaurant activity
        Intent i = getIntent();
        restaurant = (Restaurant) i.getSerializableExtra("restaurant_class");
        final String restaurant_id = restaurant.getRestaurantId();

        //set restaurant header details to views
        textViewName = (TextView) findViewById(R.id.header_restaurant_name);
        textViewType = (TextView) findViewById(R.id.header_restaurant_type);
        btn_viewCart = (Button) findViewById(R.id.btn_viewCart);
        textViewName.setText(restaurant.getRestaurantName());
        textViewType.setText("(" + restaurant.getRestaurantType() + ")");

        //get data from firebase to recycler view
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("tbl_food");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()){
                    if (ds.exists()){
                        if (ds.child("r_id").getValue().equals(restaurant_id)) {
                            foodList.add(new Food(ds.child("f_id").getValue().toString(),
                                    ds.child("f_name").getValue().toString(),
                                    ds.child("f_price").getValue().toString(),
                                    ds.child("r_id").getValue().toString()));
                        }
                    }
                }
                recyclerView = (RecyclerView) findViewById(R.id.rvFood);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(FoodActivity.this));
                foodAdapter = new FoodAdapter(getBaseContext(), foodList);
                recyclerView.setAdapter(foodAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("The read failed: " + error.getCode());
            }
        });

        btn_viewCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getBaseContext(), CartActivity.class);
                startActivity(i);
            }
        });
    }
}